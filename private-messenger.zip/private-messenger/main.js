import { addMessage, activeRoom, createRoom, deleteMessage, initState, joinRoom, persist, removeRoom, setActiveRoom, state, updateMessage, updateProfile } from './state.js';
import { broadcastMessage, broadcastTyping, startRealtime } from './realtime.js';
import { addPendingAttachment, applyStaticI18n, clearComposer, closeModal, configureUI, currentReply, focusComposer, getComposerText, getPendingAttachments, openInfoModal, openRoomModal, openSettingsModal, openShareModal, render, selectedMessages, setReply, showToast, toggleSelected } from './ui.js';
import { initLocalI18n, t } from './i18n.js';
let recorder = null;
let recordingStarted = 0;
let cameraStream = null;

function getMessage(id) { return activeRoom()?.messages.find((message) => message.id === id); }

async function selectRoom(id) {
  await setActiveRoom(id);
  document.getElementById('sidebar')?.classList.remove('open');
  render();
  document.getElementById('mainView')?.focus();
}

async function sendMessage() {
  const text = getComposerText();
  const reply = currentReply();
  const attachments = getPendingAttachments();
  if (!text && !attachments.length) return;
  const finalText = reply ? `${t('chat.replyPrefix')} ${reply.sender}: ${reply.text}
${text}`.trim() : text;
  const message = await addMessage(finalText, attachments);
  if (message) {
    broadcastMessage(message, state.activeConversationId);
    clearComposer();
    render();
    setTimeout(async () => { await updateMessage(message.id, { status: 'delivered' }); render(); }, 650);
    setTimeout(async () => { await updateMessage(message.id, { status: 'read' }); render(); }, 1450);
  }
}

async function handleForm(type, formData) {
  if (type === 'new-room' || type === 'new-group') {
    const room = await createRoom(formData.get('name') || '', type === 'new-group' ? 'group' : 'room');
    closeModal(); render(); openShareModal(room); showToast(t(type === 'new-group' ? 'toast.groupCreated' : 'toast.roomCreated')); return;
  }
  if (type === 'join-room') {
    const code = String(formData.get('code') || '').trim();
    if (code.length < 4) return showToast(t('toast.enterRoomCode'), 'error');
    const room = await joinRoom(code, formData.get('name') || '');
    closeModal(); render(); showToast(t('toast.joinedRoom', { name: room.name })); return;
  }
  if (type === 'settings') {
    await updateProfile({ displayName: String(formData.get('displayName') || 'Guest').trim() || 'Guest', status: String(formData.get('status') || '').trim() || t('profile.available'), avatar: (String(formData.get('displayName') || 'G').trim() || 'G').slice(0, 1).toUpperCase() });
    state.sound = formData.get('sound') === 'on';
    await persist(); closeModal(); render(); showToast(t('toast.settingsSaved'));
  }
}

async function handleMessageAction(action, id) {
  const message = getMessage(id);
  if (!message) return;
  if (action === 'reply') { setReply(message); showToast(t('toast.replying')); return; }
  if (action === 'copy') { try { await navigator.clipboard.writeText(message.text); showToast(t('toast.copied')); } catch { showToast(t('toast.copyUnavailable'), 'error'); } return; }
  if (action === 'select') { toggleSelected(id); return; }
  if (action === 'edit') {
    const next = window.prompt(t('actions.editPrompt'), message.text);
    if (next?.trim()) { await updateMessage(id, { text: next.trim(), edited: true }); render(); showToast(t('toast.messageEdited')); }
    return;
  }
  if (action === 'delete') {
    if (window.confirm(t('actions.deletePrompt'))) { await deleteMessage(id); render(); showToast(t('toast.messageDeleted')); }
  }
}

async function handleAction(action, event) {
  if (action === 'new-room') return openRoomModal('new');
  if (action === 'join-room') return openRoomModal('join');
  if (action === 'create-group') return openRoomModal('group');
  if (action === 'settings') return openSettingsModal();
  if (action === 'close-modal') return closeModal();
  if (action === 'back-home') { state.activeConversationId = null; await persist(); return render(); }
  if (action === 'share-room') return openShareModal(activeRoom());
  if (action === 'room-info') return openInfoModal(activeRoom());
  if (action === 'leave-room') { const room = activeRoom(); await removeRoom(room.id); closeModal(); render(); showToast(t('toast.leftRoom')); return; }
  if (action === 'send-message') return sendMessage();
  if (action === 'attach') return document.getElementById('fileInput')?.click();
  if (action === 'record-voice') return toggleRecording();
  if (action === 'toggle-theme') return toggleTheme();
  if (action === 'copy-room-code') return copyText(activeRoom()?.code || document.getElementById('shareCode')?.textContent || '');
  if (action === 'copy-device-id') return copyText(state.profile.deviceId);
  if (action === 'native-share') return shareRoom();
  if (action === 'scan-qr') return scanQr();
}

async function copyText(text) {
  if (!text) return;
  try { await navigator.clipboard.writeText(text); showToast(t('toast.copied')); } catch { showToast(t('toast.copyUnavailable'), 'error'); }
}

async function shareRoom() {
  const room = activeRoom();
  if (!room) return;
  const shareData = { title: 'Private Messenger', text: `${room.name} · ${room.code}` };
  try { if (navigator.share) await navigator.share(shareData); else await copyText(`${room.name} · ${room.code}`); } catch (error) { if (error.name !== 'AbortError') showToast(t('toast.shareUnavailable'), 'error'); }
}

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  persist(); render();
}

async function toggleRecording() {
  if (recorder?.state === 'recording') { recorder.stop(); return; }
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) return showToast(t('toast.voiceUnsupported'), 'error');
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    recorder = new MediaRecorder(stream); recordingStarted = Date.now();
    const chunks = [];
    recorder.ondataavailable = (event) => chunks.push(event.data);
    recorder.onstop = () => { stream.getTracks().forEach((track) => track.stop()); const seconds = Math.max(1, Math.round((Date.now() - recordingStarted) / 1000)); addPendingAttachment({ name: `${t('chat.voiceMessage')} · 0:${String(seconds).padStart(2, '0')}`, type: 'audio/webm', size: chunks.reduce((total, chunk) => total + chunk.size, 0) }); recorder = null; showToast(t('toast.voiceReady')); };
    recorder.start(); showToast(t('toast.recording'));
  } catch { showToast(t('toast.microphoneDenied'), 'error'); recorder = null; }
}

async function scanQr() {
  if (!('BarcodeDetector' in window) || !navigator.mediaDevices?.getUserMedia) return showToast(t('toast.scannerUnavailable'), 'error');
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    const video = document.getElementById('cameraVideo'); const box = document.getElementById('cameraBox');
    if (!video || !box) return;
    video.srcObject = cameraStream; box.classList.add('active');
    const detector = new BarcodeDetector({ formats: ['qr_code'] });
    const scan = async () => {
      if (!cameraStream) return;
      try {
        const codes = await detector.detect(video);
        const value = codes[0]?.rawValue || '';
        const match = value.match(/ROOM-[A-Z0-9]+/i);
        if (match) { const input = document.querySelector('[data-form="join-room"] input[name="code"]'); if (input) input.value = match[0].toUpperCase(); stopCamera(); showToast(t('toast.qrRead')); return; }
      } catch { /* camera frame not ready */ }
      requestAnimationFrame(scan);
    };
    requestAnimationFrame(scan);
  } catch { showToast(t('toast.cameraDenied'), 'error'); }
}

function stopCamera() { cameraStream?.getTracks().forEach((track) => track.stop()); cameraStream = null; document.getElementById('cameraBox')?.classList.remove('active'); }

function handleRealtime(event) {
  if (event.type === 'typing' && event.conversationId === state.activeConversationId) {
    const line = document.getElementById('typingLine'); if (line) line.textContent = event.active ? t('chat.peerTyping') : '';
    return;
  }
  if (event.type === 'message') {
    const room = state.conversations.find((item) => item.id === event.conversationId);
    if (!room || room.messages.some((message) => message.id === event.message?.id)) return;
    addMessage(event.message.text, event.message.attachments || [], false, event.conversationId).then(render);
  }
}

async function boot() {
  await initLocalI18n();
  await initState();
  configureUI({
    selectRoom,
    action: handleAction,
    form: handleForm,
    messageAction: handleMessageAction,
    typing: (value) => broadcastTyping(state.activeConversationId, Boolean(value)),
  });
  bindExtraControls();
  bindGlobalEvents();
  startRealtime(handleRealtime);
  render();
  applyStaticI18n();
}

function bindExtraControls() {
  document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
  document.getElementById('profileButton')?.addEventListener('click', openSettingsModal);
  document.addEventListener('keydown', (event) => { if (event.target.id === 'messageInput' && event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage(); } });
}

function bindGlobalEvents() { import('./ui.js').then(({ bindGlobalEvents: bind }) => bind()); }

boot().catch(() => showToast(t('toast.startupError'), 'error'));
