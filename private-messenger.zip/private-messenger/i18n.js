let catalog = {};

function readPath(path, values = {}) {
  const value = path.split('.').reduce((current, part) => current?.[part], catalog);
  if (typeof value !== 'string') return path;
  return value.replace(/\{(\w+)\}/g, (_, key) => values[key] == null ? `{${key}}` : String(values[key]));
}

export async function initLocalI18n() {
  try {
    const response = await fetch('./locales/en.json', { cache: 'no-store' });
    if (response.ok) catalog = await response.json();
  } catch (error) {
    console.warn('Local translation fallback unavailable', error);
  }
  window.localMessengerI18n = { t: readPath };
}

export function t(key, values) {
  let platformValue = '';
  try {
    platformValue = typeof window.miniappI18n?.t === 'function' ? window.miniappI18n.t(key, values) : '';
  } catch (error) {
    platformValue = '';
  }
  return platformValue && platformValue !== key ? platformValue : window.localMessengerI18n?.t(key, values) || readPath(key, values);
}
