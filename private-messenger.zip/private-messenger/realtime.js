let channel;
let receiver = () => {};
const instanceId = crypto.randomUUID?.() || Math.random().toString(36).slice(2);

export function startRealtime(onMessage) {
  receiver = onMessage;
  if ('BroadcastChannel' in window) {
    channel = new BroadcastChannel('private-messenger-room-events');
    channel.onmessage = (event) => {
      if (event.data?.source !== instanceId) receiver(event.data);
    };
  }
}

export function broadcastMessage(message, conversationId) {
  channel?.postMessage({ source: instanceId, type: 'message', conversationId, message });
}

export function broadcastTyping(conversationId, active) {
  channel?.postMessage({ source: instanceId, type: 'typing', conversationId, active });
}

export function stopRealtime() { channel?.close(); channel = null; }
