import { read, write } from './storage.js';
import { t } from './i18n.js';
const KEY = 'private_messenger_state_v1';
export const state = {
  ready: false,
  profile: null,
  theme: 'dark',
  sound: true,
  conversations: [],
  activeConversationId: null,
};

const makeId = (prefix = 'id') => `${prefix}_${crypto.randomUUID?.() || `${Date.now()}_${Math.random().toString(36).slice(2)}`}`;
const makeCode = () => `ROOM-${Math.random().toString(36).slice(2, 6).toUpperCase()}${Math.floor(10 + Math.random() * 90)}`;
const now = () => new Date().toISOString();
const initials = (name = 'Guest') => name.trim().slice(0, 1).toUpperCase() || 'G';

function starter() {
  const created = now();
  return {
    profile: { deviceId: `GUEST-${Math.random().toString(36).slice(2, 8).toUpperCase()}`, displayName: t('profile.guest'), status: t('profile.available'), avatar: 'G' },
    theme: 'dark', sound: true,
    activeConversationId: null,
    conversations: [{
      id: 'demo-room', name: 'নিরাপদ আলাপ', code: 'SAFE-2048', kind: 'room', members: 2, online: true, unread: 0,
      messages: [
        { id: 'm1', sender: 'Nila', senderAvatar: 'ন', text: 'স্বাগতম! এই room-এ আপনার কথোপকথন private থাকবে।', time: created, status: 'read', mine: false },
        { id: 'm2', sender: 'Nila', senderAvatar: 'ন', text: 'Room code বা QR শেয়ার করে বন্ধুকে আমন্ত্রণ জানান।', time: created, status: 'read', mine: false }
      ]
    }]
  };
}

function normalize(saved) {
  const base = starter();
  const next = { ...base, ...(saved || {}) };
  next.profile = { ...base.profile, ...(saved?.profile || {}) };
  next.profile.avatar = next.profile.avatar || initials(next.profile.displayName);
  next.conversations = Array.isArray(next.conversations) && next.conversations.length ? next.conversations : base.conversations;
  next.conversations = next.conversations.map((room) => ({ ...room, messages: Array.isArray(room.messages) ? room.messages : [], unread: room.unread || 0 }));
  if (next.activeConversationId && !next.conversations.some((room) => room.id === next.activeConversationId)) next.activeConversationId = null;
  return next;
}

export async function initState() {
  const saved = await read(KEY);
  Object.assign(state, normalize(saved), { ready: true });
  return state;
}

export async function persist() {
  const { ready, ...saved } = state;
  return write(KEY, saved);
}

export function activeRoom() { return state.conversations.find((room) => room.id === state.activeConversationId) || null; }

export async function setActiveRoom(id) {
  if (!state.conversations.some((room) => room.id === id)) return;
  state.activeConversationId = id;
  const room = activeRoom();
  if (room) room.unread = 0;
  await persist();
}

export async function createRoom(name, kind = 'room') {
  const room = { id: makeId('room'), name: name.trim() || t('home.defaultRoom'), code: makeCode(), kind, members: 1, online: true, unread: 0, messages: [] };
  state.conversations.unshift(room);
  state.activeConversationId = room.id;
  await persist();
  return room;
}

export async function joinRoom(code, name = '') {
  const cleanCode = code.trim().toUpperCase();
  const existing = state.conversations.find((room) => room.code === cleanCode);
  if (existing) { await setActiveRoom(existing.id); return existing; }
  const room = { id: makeId('room'), name: name.trim() || t('home.joinedRoom'), code: cleanCode || makeCode(), kind: 'room', members: 2, online: true, unread: 0, messages: [{ id: makeId('m'), sender: t('profile.system'), senderAvatar: '✦', text: t('chat.joinedMessage'), time: now(), status: 'read', mine: false }] };
  state.conversations.unshift(room);
  state.activeConversationId = room.id;
  await persist();
  return room;
}

export async function addMessage(text, attachments = [], mine = true, roomId = state.activeConversationId) {
  const room = state.conversations.find((item) => item.id === roomId);
  if (!room || (!text.trim() && !attachments.length)) return null;
  const message = { id: makeId('msg'), sender: mine ? state.profile.displayName : 'Peer', senderAvatar: mine ? state.profile.avatar : 'P', text: text.trim(), attachments, time: now(), status: mine ? 'sent' : 'delivered', mine };
  room.messages.push(message);
  if (!mine && roomId !== state.activeConversationId) room.unread = (room.unread || 0) + 1;
  await persist();
  return message;
}

export async function updateMessage(messageId, changes) {
  const room = activeRoom();
  const message = room?.messages.find((item) => item.id === messageId);
  if (!message) return null;
  Object.assign(message, changes);
  await persist();
  return message;
}

export async function deleteMessage(messageId) {
  const room = activeRoom();
  if (!room) return false;
  room.messages = room.messages.filter((item) => item.id !== messageId);
  await persist();
  return true;
}

export async function updateProfile(changes) {
  Object.assign(state.profile, changes);
  state.profile.avatar = state.profile.avatar || initials(state.profile.displayName);
  await persist();
}

export async function removeRoom(roomId) {
  state.conversations = state.conversations.filter((room) => room.id !== roomId);
  state.activeConversationId = state.conversations[0]?.id || null;
  await persist();
}
