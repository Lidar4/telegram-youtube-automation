import { activeRoom, state } from './state.js';
import { drawQr } from './qr.js';
import { t } from './i18n.js';

let searchTerm = '';
let pendingAttachments = [];
let replyTo = null;
let selectedIds = new Set();
let handlers = {};

export function configureUI(nextHandlers) { handlers = nextHandlers; }
export function getPendingAttachments() { return [...pendingAttachments]; }
export function clearComposer() { pendingAttachments = []; replyTo = null; }
export function addPendingAttachment(file) { pendingAttachments.push(file); renderComposerExtras(); }
export function setReply(message) { replyTo = message; renderComposerExtras(); document.getElementById('messageInput')?.focus(); }
export function applyStaticI18n() {
  document.querySelectorAll('[data-i18n]').forEach((node) => { node.textContent = t(node.dataset.i18n); });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((node) => { node.placeholder = t(node.dataset.i18nPlaceholder); });
  document.querySelectorAll('[data-i18n-aria-label]').forEach((node) => { node.setAttribute('aria-label', t(node.dataset.i18nAriaLabel)); });
}

const escapeHtml = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
const formatTime = (iso) => new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
const formatDate = (iso) => new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short' }).format(new Date(iso));
const avatar = (letter, extra = '') => `<span class="avatar ${extra}">${escapeHtml(letter || 'G')}</span>`;

export function showToast(message, tone = 'normal') {
  const region = document.getElementById('toastRegion');
  if (!region) return;
  const toast = document.createElement('div');
  toast.className = `toast ${tone}`;
  toast.textContent = message;
  region.appendChild(toast);
  setTimeout(() => toast.remove(), 3600);
}

export function render() {
  document.documentElement.dataset.theme = state.theme;
  const profileName = document.getElementById('profileName');
  const profileStatus = document.getElementById('profileStatus');
  const profileAvatar = document.getElementById('profileAvatar');
  if (profileName) profileName.textContent = state.profile.displayName;
  if (profileStatus) profileStatus.textContent = state.profile.status;
  if (profileAvatar) profileAvatar.textContent = state.profile.avatar;
  renderConversationList();
  renderMain();
  applyStaticI18n();
}

function renderConversationList() {
  const list = document.getElementById('conversationList');
  const count = document.getElementById('conversationCount');
  if (!list) return;
  const rooms = state.conversations.filter((room) => `${room.name} ${room.code}`.toLowerCase().includes(searchTerm.toLowerCase()));
  if (count) count.textContent = String(state.conversations.length);
  list.innerHTML = rooms.length ? rooms.map((room) => {
    const last = room.messages[room.messages.length - 1];
    return `<button class="conversation-item ${room.id === state.activeConversationId ? 'active' : ''}" data-room-id="${room.id}" type="button">
      ${avatar(room.kind === 'group' ? '♧' : room.name.slice(0, 1), '')}
      <span class="conversation-meta"><strong>${escapeHtml(room.name)}</strong><span>${escapeHtml(last?.text || t('home.noMessages'))}</span></span>
      ${room.unread ? `<span class="unread">${room.unread}</span>` : ''}
    </button>`;
  }).join('') : `<div class="empty-state"><div><strong>${t('home.noResults')}</strong><span>${t('home.tryAnotherSearch')}</span></div></div>`;
}

function renderMain() {
  const main = document.getElementById('mainView');
  if (!main) return;
  const room = activeRoom();
  main.innerHTML = room ? renderChat(room) : renderHome();
  if (room) {
    renderComposerExtras();
    const messages = document.getElementById('messages');
    if (messages) messages.scrollTop = messages.scrollHeight;
  }
}

function renderHome() {
  const recent = state.conversations.slice(0, 3);
  return `<section class="home-screen">
    <div class="home-intro"><span class="eyebrow">${t('home.eyebrow')}</span>
      <h1>${t('home.heroTitle')}</h1><p>${t('home.heroText')}</p>
      <div class="home-actions"><button class="primary-button" data-action="new-room" type="button">＋ ${t('actions.newChat')}</button><button class="secondary-button" data-action="join-room" type="button">↗ ${t('actions.joinRoom')}</button></div>
    </div>
    <div class="home-grid">
      <article class="feature-card"><span class="feature-icon">⌁</span><strong>${t('home.featurePrivateTitle')}</strong><p>${t('home.featurePrivateText')}</p></article>
      <article class="feature-card"><span class="feature-icon">⌗</span><strong>${t('home.featureRoomTitle')}</strong><p>${t('home.featureRoomText')}</p></article>
      <article class="feature-card"><span class="feature-icon">↯</span><strong>${t('home.featureFastTitle')}</strong><p>${t('home.featureFastText')}</p></article>
    </div>
    <section class="recent-preview"><div class="recent-heading"><h2>${t('home.recentTitle')}</h2><span>${t('home.deviceLabel', { id: state.profile.deviceId })}</span></div>
      ${recent.length ? recent.map((room) => `<button class="conversation-item ${room.id === state.activeConversationId ? 'active' : ''}" data-room-id="${room.id}" type="button">${avatar(room.kind === 'group' ? '♧' : room.name.slice(0, 1))}<span class="conversation-meta"><strong>${escapeHtml(room.name)}</strong><span>${escapeHtml(room.code)} · ${room.members} ${t('chat.members')}</span></span><span>›</span></button>`).join('') : `<div class="empty-state"><div><strong>${t('home.emptyTitle')}</strong><span>${t('home.emptyText')}</span></div></div>`}
    </section>
  </section>`;
}

function renderChat(room) {
  const messages = room.messages.length ? room.messages.map(renderMessage).join('') : `<div class="empty-state"><div><strong>${t('chat.emptyTitle')}</strong><span>${t('chat.emptyText')}</span></div></div>`;
  return `<section class="chat-screen">
    <header class="chat-header"> <button class="icon-button back-button" data-action="back-home" type="button" aria-label="${t('actions.back')}">‹</button>${avatar(room.kind === 'group' ? '♧' : room.name.slice(0, 1))}<div class="chat-title"><strong>${escapeHtml(room.name)}</strong><span>${room.online ? `● ${t('chat.online')} · ${room.members} ${t('chat.members')}` : t('chat.offline')}</span></div><span class="room-code-chip">${escapeHtml(room.code)}</span><div class="chat-header-actions"><button class="icon-button" data-action="share-room" type="button" aria-label="${t('actions.share')}">⌁</button><button class="icon-button" data-action="room-info" type="button" aria-label="${t('actions.roomInfo')}">ⓘ</button></div></header>
    <div id="messages" class="messages">${messages}</div>
    <div class="composer-wrap"><div id="typingLine" class="typing-line"></div><div id="attachmentStrip" class="attachment-strip"></div><div class="composer"><button class="icon-button" data-action="attach" type="button" aria-label="${t('actions.attach')}">＋</button><input id="fileInput" type="file" multiple hidden accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"><textarea id="messageInput" rows="1" maxlength="3000" data-i18n-placeholder="chat.placeholder" placeholder="${t('chat.placeholder')}"></textarea><button class="icon-button" data-action="record-voice" type="button" aria-label="${t('actions.voice')}">♬</button><button class="icon-button send-button" data-action="send-message" type="button" aria-label="${t('actions.send')}">➤</button></div><small class="composer-hint">${t('chat.composerHint')}</small></div>
  </section>`;
}

function renderMessage(message) {
  const attachmentHtml = (message.attachments || []).map((file) => `<div class="attachment-card"><span>${file.type?.startsWith('image') ? '▧' : file.type?.startsWith('audio') ? '♬' : '▤'}</span><strong>${escapeHtml(file.name)}</strong><span>↓</span></div>`).join('');
  const status = message.mine ? t(`status.${message.status || 'sent'}`) : '';
  return `<article class="message-row ${message.mine ? 'mine' : ''} ${selectedIds.has(message.id) ? 'selected' : ''}" data-message-id="${message.id}">${avatar(message.senderAvatar)}<div class="bubble-wrap"><div class="message-author">${escapeHtml(message.sender)}${message.edited ? ` · ${t('chat.edited')}` : ''}</div><div class="bubble">${attachmentHtml}${message.text ? `<p>${escapeHtml(message.text)}</p>` : ''}<span class="message-time">${formatTime(message.time)}${status ? ` · ${status}` : ''}</span></div><div class="message-actions"><button data-message-action="reply" data-message-id="${message.id}" type="button">${t('actions.reply')}</button><button data-message-action="copy" data-message-id="${message.id}" type="button">${t('actions.copy')}</button><button data-message-action="select" data-message-id="${message.id}" type="button">${selectedIds.has(message.id) ? t('actions.deselect') : t('actions.select')}</button>${message.mine ? `<button data-message-action="edit" data-message-id="${message.id}" type="button">${t('actions.edit')}</button><button data-message-action="delete" data-message-id="${message.id}" type="button">${t('actions.delete')}</button>` : ''}</div></div></article>`;
}

function renderComposerExtras() {
  const strip = document.getElementById('attachmentStrip');
  if (!strip) return;
  strip.innerHTML = [...pendingAttachments, ...(replyTo ? [{ name: `${t('chat.replyingTo')}: ${replyTo.text.slice(0, 28)}` }] : [])].map((file, index) => `<span class="file-chip">${escapeHtml(file.name)}${index < pendingAttachments.length ? ' ×' : ''}</span>`).join('');
  strip.classList.toggle('has-items', pendingAttachments.length > 0 || Boolean(replyTo));
}

export function openModal(content, className = '') {
  const root = document.getElementById('modalRoot');
  root.innerHTML = `<div class="modal-backdrop" data-close="true"><section class="modal ${className}" role="dialog" aria-modal="true">${content}</section></div>`;
  root.querySelector('[data-close]')?.addEventListener('click', (event) => { if (event.target.dataset.close) closeModal(); });
  root.querySelector('[data-action="close-modal"]')?.addEventListener('click', closeModal);
}
export function closeModal() { document.getElementById('modalRoot').innerHTML = ''; }

export function openRoomModal(mode = 'new') {
  const isJoin = mode === 'join';
  const formType = isJoin ? 'join-room' : mode === 'group' ? 'new-group' : 'new-room';
  openModal(`<div class="modal-heading"><div><span class="eyebrow">${isJoin ? t('modal.joinEyebrow') : mode === 'group' ? t('modal.groupEyebrow') : t('modal.newEyebrow')}</span><h2>${isJoin ? t('modal.joinTitle') : mode === 'group' ? t('modal.groupTitle') : t('modal.newTitle')}</h2><p>${isJoin ? t('modal.joinText') : mode === 'group' ? t('modal.groupText') : t('modal.newText')}</p></div><button class="icon-button" data-action="close-modal" type="button">×</button></div><form data-form="${formType}"><label class="form-field"> <span>${t('modal.roomName')}</span><input name="name" maxlength="44" placeholder="${t('modal.roomNamePlaceholder')}"></label>${isJoin ? `<label class="form-field"><span>${t('modal.roomCode')}</span><input name="code" required maxlength="20" placeholder="ROOM-ABCD12" autocomplete="off"><button class="ghost-button" data-action="scan-qr" type="button">▣ ${t('actions.scanQr')}</button><div id="cameraBox" class="camera-box"><video id="cameraVideo" autoplay muted playsinline></video></div></label>` : ''}<div class="modal-actions"><button class="ghost-button" data-action="close-modal" type="button">${t('actions.cancel')}</button><button class="primary-button" type="submit">${isJoin ? t('actions.joinRoom') : t('actions.createRoom')}</button></div></form>`);
}

export function openShareModal(room) {
  openModal(`<div class="modal-heading"><div><span class="eyebrow">${t('modal.shareEyebrow')}</span><h2>${t('modal.shareTitle')}</h2><p>${t('modal.shareText')}</p></div><button class="icon-button" data-action="close-modal" type="button">×</button></div><div class="code-display"><div><span>${t('modal.roomCode')}</span><strong id="shareCode">${escapeHtml(room.code)}</strong></div><button id="copyRoomCode" class="secondary-button" data-action="copy-room-code" type="button">${t('actions.copy')}</button></div><div class="qr-wrap"><canvas id="roomQr" width="180" height="180" aria-label="QR code"></canvas></div><div class="modal-actions"><button class="primary-button" data-action="native-share" type="button">${t('actions.share')}</button></div>`);
  const canvas = document.getElementById('roomQr');
  if (canvas) drawQr(canvas, room.code);
}

export function openSettingsModal() {
  openModal(`<div class="modal-heading"><div><span class="eyebrow">${t('modal.settingsEyebrow')}</span><h2>${t('modal.settingsTitle')}</h2><p>${t('modal.settingsText')}</p></div><button class="icon-button" data-action="close-modal" type="button">×</button></div><form data-form="settings"><div class="settings-section"><h3>${t('settings.identity')}</h3><label class="form-field"><span>${t('settings.displayName')}</span><input name="displayName" maxlength="30" value="${escapeHtml(state.profile.displayName)}"></label><label class="form-field"><span>${t('settings.status')}</span><input name="status" maxlength="60" value="${escapeHtml(state.profile.status)}"></label><div class="setting-row"><div><strong>${t('settings.deviceId')}</strong><small>${escapeHtml(state.profile.deviceId)}</small></div><button class="ghost-button" data-action="copy-device-id" type="button">${t('actions.copy')}</button></div></div><div class="settings-section"><h3>${t('settings.preferences')}</h3><div class="setting-row"><div><strong>${t('settings.sound')}</strong><small>${t('settings.soundHint')}</small></div><label class="switch"><input name="sound" type="checkbox" ${state.sound ? 'checked' : ''}><span></span></label></div><div class="setting-row"><div><strong>${t('settings.theme')}</strong><small>${state.theme === 'dark' ? t('settings.dark') : t('settings.light')}</small></div><button class="ghost-button" data-action="toggle-theme" type="button">${t('settings.change')}</button></div></div><div class="modal-actions"><button class="ghost-button" data-action="close-modal" type="button">${t('actions.cancel')}</button><button class="primary-button" type="submit">${t('actions.save')}</button></div></form>`);
}

export function openInfoModal(room) {
  openModal(`<div class="modal-heading"><div><span class="eyebrow">${t('modal.roomEyebrow')}</span><h2>${escapeHtml(room.name)}</h2><p>${t('modal.roomText')}</p></div><button class="icon-button" data-action="close-modal" type="button">×</button></div><div class="settings-section"><div class="setting-row"><div><strong>${t('modal.roomCode')}</strong><small>${escapeHtml(room.code)}</small></div><button class="ghost-button" data-action="copy-room-code" type="button">${t('actions.copy')}</button></div><div class="setting-row"><div><strong>${t('modal.members')}</strong><small>${room.members} ${t('chat.members')}</small></div><span class="status-dot"></span></div></div><div class="modal-actions"><button class="danger-button" data-action="leave-room" type="button">${t('actions.leaveRoom')}</button></div>`);
}

export function bindGlobalEvents() {
  document.addEventListener('click', async (event) => {
    const roomButton = event.target.closest('[data-room-id]');
    if (roomButton) return handlers.selectRoom?.(roomButton.dataset.roomId);
    const action = event.target.closest('[data-action]')?.dataset.action;
    if (action) return handlers.action?.(action, event);
    const messageButton = event.target.closest('[data-message-action]');
    if (messageButton) return handlers.messageAction?.(messageButton.dataset.messageAction, messageButton.dataset.messageId);
  });
  document.addEventListener('submit', (event) => {
    const form = event.target.closest('[data-form]');
    if (!form) return;
    event.preventDefault();
    handlers.form?.(form.dataset.form, new FormData(form));
  });
  document.addEventListener('input', (event) => {
    if (event.target.id === 'conversationSearch') { searchTerm = event.target.value; renderConversationList(); }
    if (event.target.id === 'messageInput') handlers.typing?.(event.target.value);
  });
  document.addEventListener('change', (event) => {
    if (event.target.id === 'fileInput') {
      [...event.target.files].forEach((file) => addPendingAttachment({ name: file.name, type: file.type, size: file.size }));
      event.target.value = '';
    }
  });
  document.getElementById('sidebarToggle')?.addEventListener('click', () => document.getElementById('sidebar')?.classList.toggle('open'));
  document.addEventListener('keydown', (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); document.getElementById('conversationSearch')?.focus(); } if (event.key === 'Escape') closeModal(); });
}

export function focusComposer() { document.getElementById('messageInput')?.focus(); }
export function getComposerText() { return document.getElementById('messageInput')?.value.trim() || ''; }
export function clearSelected() { selectedIds.clear(); }
export function selectedMessages() { return [...selectedIds]; }
export function toggleSelected(id) { selectedIds.has(id) ? selectedIds.delete(id) : selectedIds.add(id); renderMain(); }
export function currentReply() { return replyTo; }
