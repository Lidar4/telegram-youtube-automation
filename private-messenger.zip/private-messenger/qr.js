const SIZE = 21;
const ECC_LEVEL_L = 1;
const GENERATOR = [87, 229, 146, 149, 238, 102, 21];

function multiply(a, b) {
  let result = 0;
  while (b) {
    if (b & 1) result ^= a;
    b >>>= 1;
    a = (a << 1) ^ ((a & 0x80) ? 0x11d : 0);
  }
  return result & 0xff;
}

function errorCorrection(data) {
  const ecc = new Array(7).fill(0);
  data.forEach((value) => {
    const factor = value ^ ecc[0];
    ecc.shift();
    ecc.push(0);
    GENERATOR.forEach((coefficient, index) => { ecc[index] ^= multiply(coefficient, factor); });
  });
  return ecc;
}

function formatBits() {
  let value = ECC_LEVEL_L << 3;
  let shifted = value << 10;
  for (let bit = 14; bit >= 10; bit--) {
    if ((shifted >>> bit) & 1) shifted ^= 0x537 << (bit - 10);
  }
  return ((value << 10) | shifted) ^ 0x5412;
}

function makeMatrix(text) {
  const bytes = new TextEncoder().encode(text);
  if (bytes.length > 17) throw new Error('QR text is too long');
  const data = [0x40, bytes.length];
  bytes.forEach((byte) => data.push(byte));
  while (data.length < 19) data.push(data.length % 2 ? 0xec : 0x11);
  const codewords = [...data, ...errorCorrection(data)];
  const bits = codewords.flatMap((byte) => Array.from({ length: 8 }, (_, index) => (byte >> (7 - index)) & 1));
  const matrix = Array.from({ length: SIZE }, () => Array(SIZE).fill(null));

  const set = (x, y, value) => { if (x >= 0 && y >= 0 && x < SIZE && y < SIZE) matrix[y][x] = Boolean(value); };
  const reserveBox = (x, y) => {
    for (let row = -1; row <= 7; row++) for (let col = -1; col <= 7; col++) set(x + col, y + row, false);
    for (let row = 0; row < 7; row++) for (let col = 0; col < 7; col++) {
      const dark = row === 0 || row === 6 || col === 0 || col === 6 || (row >= 2 && row <= 4 && col >= 2 && col <= 4);
      set(x + col, y + row, dark);
    }
  };
  reserveBox(0, 0); reserveBox(14, 0); reserveBox(0, 14);
  for (let i = 8; i < SIZE - 8; i++) { set(i, 6, i % 2 === 0); set(6, i, i % 2 === 0); }
  const format = formatBits();
  for (let i = 0; i < 15; i++) {
    const bit = (format >> i) & 1;
    if (i < 6) set(8, i, bit); else if (i < 8) set(8, i + 1, bit); else set(8, SIZE - 15 + i, bit);
    if (i < 8) set(SIZE - i - 1, 8, bit); else if (i < 9) set(15 - i, 8, bit); else set(14 - i, 8, bit);
  }
  set(8, SIZE - 8, true);

  let bitIndex = 0;
  let upward = true;
  for (let right = SIZE - 1; right >= 1; right -= 2) {
    if (right === 6) right--;
    for (let offset = 0; offset < SIZE; offset++) {
      const y = upward ? SIZE - 1 - offset : offset;
      for (const x of [right, right - 1]) {
        if (matrix[y][x] !== null) continue;
        const bit = bitIndex < bits.length ? bits[bitIndex++] : 0;
        matrix[y][x] = Boolean(bit ^ (((x + y) % 2) === 0));
      }
    }
    upward = !upward;
  }
  return matrix;
}

export function drawQr(canvas, text) {
  if (!canvas) return;
  const matrix = makeMatrix(text);
  const context = canvas.getContext('2d');
  const size = canvas.width || 180;
  const margin = Math.floor(size / 12);
  const cell = (size - margin * 2) / SIZE;
  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, size, size);
  context.fillStyle = '#102a38';
  matrix.forEach((row, y) => row.forEach((dark, x) => { if (dark) context.fillRect(margin + x * cell, margin + y * cell, Math.ceil(cell), Math.ceil(cell)); }));
}
