const memoryStore = new Map();
const storage = () => window.miniappsAI?.storage;

export async function read(key) {
  try {
    const value = storage() ? await storage().getItem(key) : memoryStore.get(key);
    return value ? JSON.parse(value) : null;
  } catch (error) {
    console.warn('Storage read failed', error);
    return null;
  }
}

export async function write(key, value) {
  try {
    const encoded = JSON.stringify(value);
    if (storage()) await storage().setItem(key, encoded);
    else memoryStore.set(key, encoded);
    return true;
  } catch (error) {
    console.warn('Storage write failed', error);
    return false;
  }
}

export async function remove(key) {
  try {
    if (storage()) await storage().removeItem(key);
    else memoryStore.delete(key);
  } catch (error) {
    console.warn('Storage remove failed', error);
  }
}
